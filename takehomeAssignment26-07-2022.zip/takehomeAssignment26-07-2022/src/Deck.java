import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Deck {
	
	private List<Card> cards = new ArrayList<Card>();
	private List<String> ranks = new ArrayList<String>();
	private List<String> suits = new ArrayList<String>();
	
	public Deck() {
		initializeRanks();
		initializeSuits();
		initializeDeck();
		
	}
	
	public void initializeDeck() {
		
		for(String suit : this.suits) {
			for(String rank : this.ranks) {
				Card card = new Card(rank, suit);
				this.cards.add(card);
			}
		}
		
	}
	
	public void initializeRanks() {
		this.ranks.add("Ace");
		this.ranks.add("2");
		this.ranks.add("3");
		this.ranks.add("4");
		this.ranks.add("5");
		this.ranks.add("6");
		this.ranks.add("7");
		this.ranks.add("8");
		this.ranks.add("9");
		this.ranks.add("10");
		this.ranks.add("Jack");
		this.ranks.add("Queen");
		this.ranks.add("King");
	}
	
	public void initializeSuits() {
		this.suits.add("Diamonds");
		this.suits.add("Clubs");
		this.suits.add("Hearts");
		this.suits.add("Spades");
		
	}
	
	public void shuffleCards() {
		Collections.shuffle(cards);
	}
	
	public void displayDeck() {
		System.out.println(this.cards);
	}

	public List<Card> getCards() {
		return cards;
	}
	
	public List<String> getRanks() {
		return ranks;
	}
	
	public List<String> getSuits() {
		return suits;
	}
	
}
