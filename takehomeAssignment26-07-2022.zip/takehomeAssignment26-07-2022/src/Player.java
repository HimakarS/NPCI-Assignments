public class Player {
	
	private String name;
	private int coins = 100;
	private Card chosenCard;
	private String chosenOrientation;
	
	public Player(String name, Card chosenCard, String orientation) {
		this.name = name;
		this.chosenCard = chosenCard;
		this.chosenOrientation = orientation;
	}
	
	public void placeBet(int betAmount) {
		this.coins -= betAmount;
	}
	
	public void addWinnings(int amount) {
		this.coins += amount;
	}

	@Override
	public String toString() {
		return "Player [name=" + name + ", chosenCard=" + chosenCard + ", chosenOrientation=" + chosenOrientation + "]";
	}
	
	public Card getChosenCard() {
		return this.chosenCard;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getChosenOrientation() {
		return this.chosenOrientation;
	}
	
	
	
	
}
