import java.util.Scanner;

public class PlayGame {

	public static void main(String[] args) {
		
//		Deck deck = new Deck();
//		deck.displayDeck();
		
		Game game = new Game();
		game.shuffleCards();
		game.printShuffledCards();
		game.takePlayersDetails();
//		System.out.println(game.getPlayers());
		
		game.selectHost();
		System.out.println(game.getHost().getName() + " is the host.");
		System.out.println(game.getPlayers());
		System.out.println(game.getCardsSelectedByPlayers());
		game.deal();
		
		Scanner sc = new Scanner(System.in);
		
		
		boolean proceed = true;
		while(proceed) {
			System.out.print("Enter YES to continue: ");
			String option = sc.next();
			if(option.equals("YES")) {
				game.continueGame();
			}
			else proceed = false;
		}
	}

}
