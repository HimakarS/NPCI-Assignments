import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Game {
	
	private int numberOfPlayers;
	private List<Player> playersList = new ArrayList<Player>();
	private Deck gameDeck;
	private List<Card> inList = new ArrayList<Card>();
	private List<Card> outList = new ArrayList<Card>();
	private List<Card> cardsSelectedByPlayers = new ArrayList<Card>();
	private Player winner;
	private Player host;
	
	
	public Game() {
		this.gameDeck = new Deck();
	}
	
	public void takePlayersDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of players: ");
		this.numberOfPlayers = sc.nextInt();
		for(int i = 0; i < numberOfPlayers; i++) {
			System.out.println("--------Player " + (i + 1) + "--------");
			
			sc.nextLine();
			System.out.print("Enter the name: ");
			String name = sc.nextLine();
			
			System.out.print("Enter the rank of the chosen card: ");
			String rank = sc.next();
			boolean validRank = false;
			while(!validRank) {
				if(gameDeck.getRanks().contains(rank)) {
					validRank = true;
				}
				else {
					System.out.print("Enter a valid rank: ");
					rank = sc.next();
				}
			}
			
			System.out.print("Enter the suit of the card chosen: ");
			String suit = sc.next();
			boolean validSuit = false;
			while(!validSuit) {
				if(gameDeck.getSuits().contains(suit)) {
					validSuit = true;
				}
				else {
					System.out.print("Enter a valid suit: ");
					suit = sc.next();
				}
			}
			
			Card card = new Card(rank, suit);
			boolean cardAlreadySelected = false;
			for(Card c : cardsSelectedByPlayers) {
				if((c.getSuit().equals(card.getSuit())) && c.getRank().equals(card.getRank())) {
					cardAlreadySelected = true;
				}
			}
			
			System.out.println(cardAlreadySelected);
			while(cardAlreadySelected) {
					System.out.println("2 players cannot select the same card.");
					
					System.out.print("Enter a valid rank: ");
					rank = sc.next();
					validRank = false;
					while(!validRank) {
						if(gameDeck.getRanks().contains(rank)) {
							validRank = true;
						}
						else {
							System.out.print("Enter a valid rank: ");
							rank = sc.next();
						}
					}
					
					System.out.print("Enter a valid suit: ");
					suit = sc.next();
					validSuit = false;
					while(!validSuit) {
						if(gameDeck.getSuits().contains(suit)) {
							validSuit = true;
						}
						else {
							System.out.print("Enter a valid suit: ");
							suit = sc.next();
						}
					}
					
					card = new Card(rank, suit);
					
					for(Card c : cardsSelectedByPlayers) {
						if((c.getSuit().equals(card.getSuit())) && c.getRank().equals(card.getRank())) {
							cardAlreadySelected = true;
						}
						else cardAlreadySelected = false;
					}
					
					System.out.println(cardAlreadySelected);
			}
			
			cardsSelectedByPlayers.add(card);
			System.out.println(cardsSelectedByPlayers);
			
			
			
			System.out.print("Enter the orientation (IN/OUT): ");
			String orientation = sc.next();
			
			Player player = new Player(name, card, orientation);
			
			this.playersList.add(player);
			
		}
		
	}
	
	public void selectHost() {
		Random rand = new Random();
        Player player = playersList.get(rand.nextInt(playersList.size()));
        this.host =  player;
        
        for(Card card : cardsSelectedByPlayers) {
        	if((card.getRank().equals(player.getChosenCard().getRank())) && (card.getSuit().equals(player.getChosenCard().getSuit()))) {
        		cardsSelectedByPlayers.remove(card);
        		break;
        	}
        }
        
        for(Player p : playersList) {
        	if((p.getName().equals(player.getName())) && p.getChosenCard().equals(player.getChosenCard())) {
        		playersList.remove(p);
        		break;
        	}
        }
        
        
	}
	
	public void deal() {
		int count = 0;
		for(Card card : this.gameDeck.getCards()) {
			if((count % 2) == 0) {
				for(Player player : this.playersList) {
					if(card.getRank().equals(player.getChosenCard().getRank()) && player.getChosenOrientation().equals("IN") && card.getSuit().equals(player.getChosenCard().getSuit())) {
						System.out.println(player.getName() + " won the game.");
						this.winner = player;
//						this.host = winner;
						return;
					}
					else {
						this.inList.add(card);
						System.out.println("Added " + card + " to the IN list.");
						break;
					}
				}
			}
			else {
				for(Player player : this.playersList) {
					if(card.getRank().equals(player.getChosenCard().getRank()) && player.getChosenOrientation().equals("OUT") && card.getSuit().equals(player.getChosenCard().getSuit())) {
						System.out.println(player.getName() + " won the game.");
						this.winner = player;
//						this.host = winner;
						return;
					}
					else {
						this.outList.add(card);
						System.out.println("Added " + card + " to the OUT list.");
						break;
					}
				}
			}
			count++;
		}
		if(count == 52) {
			this.winner = this.host;
			System.out.println("Host - " + this.host.getName() + " won the game.");
		}
	}
	
	public void shuffleCards() {
		Collections.shuffle(this.gameDeck.getCards());
	}
	
	public void printShuffledCards() {
		System.out.println(this.gameDeck.getCards());
	}
	
	public List<Player> getPlayers() {
		return this.playersList;
	}
	
	public Player getHost() {
		return this.host;
	}
	
	public List<Card> getCardsSelectedByPlayers() {
		return cardsSelectedByPlayers;
	}
	
	public void continueGame() {
		if(this.host.getChosenCard() != this.winner.getChosenCard()) {
			this.playersList.add(host);
			this.cardsSelectedByPlayers.add(host.getChosenCard());
			
			for(Card card : cardsSelectedByPlayers) {
	        	if((card.getRank().equals(this.winner.getChosenCard().getRank())) && (card.getSuit().equals(this.winner.getChosenCard().getSuit()))) {
	        		cardsSelectedByPlayers.remove(this.winner);
	        		break;
	        	}
	        }
	        
	        for(Player p : playersList) {
	        	if((p.getName().equals(this.winner.getName())) && p.getChosenCard().equals(this.winner.getChosenCard())) {
	        		playersList.remove(p);
	        		break;
	        	}
	        }
			
		}
		this.host = this.winner;
        shuffleCards();
        System.out.println(getHost().getName() + " is the host.");
        deal();
	}

}
