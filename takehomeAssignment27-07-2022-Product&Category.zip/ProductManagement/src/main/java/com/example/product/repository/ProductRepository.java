package com.example.product.repository;

import java.util.List;

import com.example.product.entity.Product;

public interface ProductRepository {
	
	List<Product> findAll();

	Product findByID(Integer productID);

	void saveOrUpdate(Product p);

	void deleteByID(Integer productID);

}
