package com.example.product.service;

import java.util.List;

import com.example.product.entity.Product;

public interface ProductService {

	List<Product> findAll();

	Product findByID(Integer productID);

	void saveOrUpdate(Product p);

	void deleteByID(Integer productID);

}
