package com.example.product.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	
	@Id
	@Column(name="id")
	private Integer productID;
	
	@Column(name="name")
	private String productName;
	
	@Column(name="description")
	private String description;
	
	@Column(name="unitprice")
	private double unitPrice;
	
	@Column(name="imageurl")
	private String imageURL;
	
	@Column(name="unitsinstock")
	private Integer unitsInStock;
	
	@Column(name="datecreated")
	private Timestamp dateCreated;
	
	@Column(name="lastupdated")
	private Timestamp lastUpdated;
	
	@Column(name="categoryid")
	private Integer categoryID;
	
	public Product() {
		
	}

	public Product(Integer productID, String productName, String description, double unitPrice, String imageURL,
			Integer unitsInStock, Timestamp dateCreated, Timestamp lastUpdated, Integer categoryID) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.description = description;
		this.unitPrice = unitPrice;
		this.imageURL = imageURL;
		this.unitsInStock = unitsInStock;
		this.dateCreated = dateCreated;
		this.lastUpdated = lastUpdated;
		this.categoryID = categoryID;
	}

	public Integer getProductID() {
		return productID;
	}

	public void setProductID(Integer productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getImageURL() {
		return imageURL;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public Integer getUnitsInStock() {
		return unitsInStock;
	}

	public void setUnitsInStock(Integer unitsInStock) {
		this.unitsInStock = unitsInStock;
	}

	public Timestamp getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Timestamp dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Timestamp getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Timestamp lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Integer getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(Integer categoryID) {
		this.categoryID = categoryID;
	}
	
	

}
