package com.example.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.entity.Product;
import com.example.product.service.ProductService;



@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/productList")
	public List<Product> display() {
		return productService.findAll();
	}
	
	@GetMapping("/p/{productID}")
	public Product findByID(@PathVariable Integer productID) throws Exception {
		Product p = productService.findByID(productID);
		if(p == null) throw new Exception("Product details not available in the repository.");
		return p;
	}
	
	@PostMapping("/saveProduct")
	public String saveProduct(@RequestBody Product p) {
		
		productService.saveOrUpdate(p);
		return "Product details saved.";
	}
	
	@PutMapping("/updateProduct")
	public String updateProduct(@RequestBody Product p) {
		productService.saveOrUpdate(p);
		return "Product ID: " + p.getProductID() + " - Details updated";
	}
	
	@DeleteMapping("delete/{productID}")
	public String deleteProductByID(@PathVariable Integer productID) {
		productService.deleteByID(productID);
		return "Product ID: " + productID + " - Details deleted";
	}


}
