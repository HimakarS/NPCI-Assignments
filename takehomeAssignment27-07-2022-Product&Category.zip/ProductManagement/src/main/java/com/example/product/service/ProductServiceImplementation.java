package com.example.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product.entity.Product;
import com.example.product.repository.ProductRepository;

@Service
public class ProductServiceImplementation implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	
	public List<Product> findAll() {
		return productRepository.findAll();
	}

	public Product findByID(Integer productID) {
		return productRepository.findByID(productID);
	}

	public void saveOrUpdate(Product p) {
		productRepository.saveOrUpdate(p);
	}

	public void deleteByID(Integer productID) {
		productRepository.deleteByID(productID);
	}

}
