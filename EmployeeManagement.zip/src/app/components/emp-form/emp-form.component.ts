import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Department } from 'src/app/common/department';
import { Employee } from 'src/app/common/employee';
import { ManagementServiceService } from 'src/app/services/management-service.service';


@Component({
  selector: 'app-emp-form',
  templateUrl: './emp-form.component.html',
  styleUrls: ['./emp-form.component.css']
})

export class EmpFormComponent implements OnInit {

  departments : Department[]
  employee : Employee = new Employee(0,"","",new Date(),0,0,0,0)
  //route: any;
  constructor(private service : ManagementServiceService, private route : Router){}

  ngOnInit(): void {
    this.listOfDepartments()
  }

  listOfDepartments() {
    this.service.getAllDepartments().subscribe(data=>{console.log(data)
    this.departments = data
  })
  }

  onsubmit(){
    //console.log(this.employee)
    this.service.saveEmployee(this.employee).subscribe(()=>{
      this.route.navigateByUrl("/employees")
    })
  }

}
