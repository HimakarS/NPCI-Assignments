export class Department {

    /*
        "deptNo" : 1001,
        "deptName" : "Development",
        "location" : "Hyderabad"
    */
   constructor(public deptNo : 10,
                public deptName : string,
                public location : string) {}

}
