export class Employee {

    /*
        "empNo" : 10001,
        "empName" : "HimakarS",
        "job" : "Computer Scientist",
        "hireDate" : "2000-12-27",
        "managerID" : "101",
        "salary" : "100000",
        "commission" : 10000,
        "deptNo" : 1002,
    */
    constructor(public empNo : number,
                public empName : String, 
                public job : String, 
                public hireDate : Date, 
                public managerID : number,
                public salary : number,
                public commission : number,
                public deptNo : number) {}

}
