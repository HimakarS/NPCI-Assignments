package com.npci.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApIwithJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
