import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LinkedListOperations {

	public static void main(String[] args) {
		
		LinkedList<Integer> ll = new LinkedList<Integer>();
		
		List <Integer> digits = new ArrayList<Integer>();
		digits.add(1);
		digits.add(2);
		digits.add(3);
		digits.add(4);
		digits.add(5);
		
		ll.addAll(digits); //addAll
		
		ll.add(6); //add
		
		System.out.println(ll.size()); //size()
		
		ll.addFirst(0); //addFirst - Adding 0 at the first index
		
		ll.addLast(6); //addLast - Adding 6 at the last index
		
		ll.add(2);
		ll.add(3);
		System.out.println(ll.lastIndexOf(2)); //lastIndexOf(2) - Returns the last index of the integer 2 in the linked list
		System.out.println(ll.lastIndexOf(10)); //Returns -1 as 10 is not present in the linked list
		System.out.println(ll.indexOf(2)); //Returns the first index of the integer 2 in the linked list
		System.out.println(ll.indexOf(10)); //Returns -1 as 10 is not present in the linked list
		
		System.out.println(ll.peek()); //Returns the head
		System.out.println(ll.peekFirst()); //Returns the first element
		System.out.println(ll.peekLast()); //Returns the last element
		
		System.out.println(ll);
		
		int head = ll.poll(); //poll() - Removes and returns the head of the linked list
		int first = ll.pollFirst(); //pollFirst() - Removes and returns the first element of the linked list
		int last = ll.pollLast(); //pollLast() - Removes and returns the last element of the linked list
		
		System.out.println("Head = " + head);
		System.out.println("First = " + first);
		System.out.println("Last = " + last);
		
		System.out.println(ll);
	}

}
