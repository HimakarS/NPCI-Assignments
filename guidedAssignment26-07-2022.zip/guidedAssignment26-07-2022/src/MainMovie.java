import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainMovie {

	public static void main(String[] args) {
		
		Movie m1 = new Movie("Movie1", "Director1", "02:30:55", 2009);
		Movie m2 = new Movie("Movie2", "Director1", "02:25:07", 2011);
		Movie m3 = new Movie("Movie3", "Director2", "01:30:57", 2013);
		Movie m4 = new Movie("Movie4", "Director2", "01:42:53", 2017);
		Movie m5 = new Movie("Movie5", "Director2", "01:37:37", 2019);
		Movie m6 = new Movie("Movie6", "Director2", "03:01:57", 2021);
		Movie m7 = new Movie("Movie7", "Director3", "02:30:17", 2013);
		Movie m8 = new Movie("Movie8", "Director3", "02:40:37", 2009);
		Movie m9 = new Movie("Movie9", "Director4", "02:30:37", 2011);
		Movie m10 = new Movie("Movie10", "Director5", "01:30:57", 2013);
		
		List<Movie> movies = new ArrayList<Movie>();
		movies.add(m1);
		movies.add(m2);
		movies.add(m3);
		movies.add(m4);
		movies.add(m5);
		movies.add(m6);
		movies.add(m7);
		movies.add(m8);
		movies.add(m9);
		movies.add(m10);
		
		HashMap<String, List<String>> directorMap = new HashMap<String, List<String>>();
		
		for(Movie m : movies) {
			String director = m.getDirectorName();
			if((!directorMap.containsKey(director))) {
				List<String> temp = new ArrayList<String>();
				temp.add(m.getName());
				directorMap.put(director, temp);
			}
			else {
//				List <String> temp = directorMap.get(director);
//				temp.add(m.getName());
//				directorMap.replace(director, temp);
				
				directorMap.get(director).add(m.getName());
			}
		}
		
		System.out.println(directorMap);
		
		System.out.println(searchMovies(directorMap, "Director2"));
		
		
		
		

	}
	
	public static List<String> searchMovies(HashMap <String, List<String>> directorMap, String director) {
		return directorMap.get(director);
	}

}
