import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListOperations {

	public static void main(String[] args) {
		List <String> listOfStrings = new ArrayList<String>();
        listOfStrings.add("C");
        listOfStrings.add("C++");
        listOfStrings.add("Java");
        listOfStrings.add("Python3");
        
        System.out.println(listOfStrings.size());
        System.out.println(listOfStrings.isEmpty());
        System.out.println(listOfStrings.get(0));
        listOfStrings.set(3, "Python");
        System.out.println(listOfStrings);
        
        List <String> newListOfStrings = new ArrayList<String>();
        newListOfStrings.add("R");
        newListOfStrings.add("MySQL");
        newListOfStrings.add("save");
        newListOfStrings.add("vase");
        newListOfStrings.add("cat");
        newListOfStrings.add("tac");
        newListOfStrings.add("Rome");
        newListOfStrings.add("more");
        listOfStrings.addAll(newListOfStrings);
        System.out.println(listOfStrings);
        
        List <String> anagramsList = new ArrayList <String>();
        
        for(int i = 0; i < listOfStrings.size(); i++) {
        	char[] charArray1 = listOfStrings.get(i).toLowerCase().toCharArray();
        	Arrays.sort(charArray1);
        	for(int j = i+1; j < listOfStrings.size(); j++) {
        		char[] charArray2 = listOfStrings.get(j).toLowerCase().toCharArray();
        		Arrays.sort(charArray2);
        		if(Arrays.equals(charArray1, charArray2)) {
        			
        			
        			anagramsList.add(listOfStrings.get(i));
        			anagramsList.add(listOfStrings.get(j));
        		}
        	}
        	
        	
        }
        System.out.println(anagramsList);

	}

}
