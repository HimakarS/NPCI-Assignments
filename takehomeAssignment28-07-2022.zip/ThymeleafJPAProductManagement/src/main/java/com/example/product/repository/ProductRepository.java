package com.example.product.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.product.entity.Product;


@Repository
public interface ProductRepository extends JpaRepository<Product, Integer>{
	
	@Query(value="SELECT * from product p where p.categoryID = ?1", nativeQuery=true)
	public List<Product> findByCategoryID(Integer ID);
	
	@Query(value="SELECT * from product p where p.name = ?1", nativeQuery=true)
	public Product findByProductName(String name);
	

}
