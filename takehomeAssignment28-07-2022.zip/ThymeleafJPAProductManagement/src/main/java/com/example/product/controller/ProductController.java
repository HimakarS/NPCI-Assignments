package com.example.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.product.entity.Product;
import com.example.product.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/productList")
	public String displayProducts(Model model) {
		List<Product> product = productService.findAll();
		model.addAttribute("PRODUCT", product);
		return "productUI/products.html";
	}
	
	@GetMapping("/addProduct")
	public String addProductForm(Model model) {
		model.addAttribute("PRODUCT", new Product());
		return "productUI/productForm.html";
	}
	
	@PostMapping("/save")
	public String save(@ModelAttribute("PRODUCT") Product product) {
		productService.save(product);
		return "redirect:/product/productList";
	}
	
	@GetMapping("/updateProduct")
	public String updateProductForm(@RequestParam("productID") Integer ID, Model model) {
		Product product = productService.findByID(ID);
		model.addAttribute("PRODUCT", product);
		return "productUI/productForm.html";
	}
	
	@GetMapping("deleteProduct")
	public String deleteByID(@RequestParam("productID") Integer ID) {
		productService.deleteByID(ID);
		return "redirect:/product/productList";
	}
	
	@GetMapping("/displayProductsByCategory")
	public String displayByCategory(@RequestParam Integer categoryID, Model model) {
		List<Product> product = productService.findByCategoryID(categoryID);
		model.addAttribute("PRODUCT", product);
		return "productUI/products.html";
	}
	
	@GetMapping("/displaySpecificProduct/{productName}")
	public String displaySpecificProduct(@PathVariable String productName, Model model) {
		Product product = productService.findByProductName(productName);
		model.addAttribute("PRODUCT", product);
		return "productUI/products.html";
	}

}
