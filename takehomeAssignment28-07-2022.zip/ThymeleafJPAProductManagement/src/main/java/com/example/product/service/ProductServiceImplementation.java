package com.example.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product.entity.Product;
import com.example.product.repository.ProductRepository;

@Service
public class ProductServiceImplementation implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	
	public List<Product> findAll() {
		return productRepository.findAll();
	}

	@Override
	public void save(Product product) {
		productRepository.save(product);
		
	}

	@Override
	public Product findByID(Integer ID) {
		Optional <Product> p = productRepository.findById(ID);
		Product product = null;
		if(p.isPresent()) product = p.get();
		return product;
	}

	@Override
	public void deleteByID(Integer ID) {
		productRepository.deleteById(ID);
		
	}

	
	
	
	public List<Product> findByCategoryID(Integer ID) {
		return productRepository.findByCategoryID(ID);
	}

	@Override
	public Product findByProductName(String productName) {
//		return productRepository.findByProductName(productName);
		Optional <Product> p = Optional.of(productRepository.findByProductName(productName));
		Product product = null;
		if(p.isPresent()) product = p.get();
		return product;
	}
	
	
	
	
}
