package com.npci.product.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="category")
public class Category {
	
	@Id
	@Column(name="categoryid")
	private Integer categoryID;
	
	@Column(name="categoryname")
	private String categoryname;
	
	public Category() {
		
	}

	public Category(Integer categoryID, String categoryname) {
		super();
		this.categoryID = categoryID;
		this.categoryname = categoryname;
	}

	public Integer getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(Integer categoryID) {
		this.categoryID = categoryID;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}
	
	


}
