package com.npci.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementRestApIwithJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementRestApIwithJpaApplication.class, args);
	}

}
