export class Product {

    /*
        "productID" : 101,
        "productName" : "MilkUpdated2",
        "description" : "Fresh milk updated",
        "unitPrice" : 28.0,
        "imageURL" : "MilkURL",
        "unitsInStock" : 100,
        "dateCreated" : "2022-07-27T18:38:07.000+00:00",
        "lastUpdated" : "2022-07-27T18:38:07.000+00:00",
        "categoryID" : 1001,
    */

    constructor(public productID : number,
                public productName : string,
                public description : string,
                public unitPrice : number,
                public imageURL : string,
                public unitsInStock : number,
                public dateCreated : string,
                public lastUpdated : string,
                public categoryID : number) {}

}
