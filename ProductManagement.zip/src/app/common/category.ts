export class Category {

    /*
        "categoryID" : 1001,
        "categoryname" : "Dairy",
    */
    
    constructor(public categoryID : number,
                public categoryname : string) {}

}
