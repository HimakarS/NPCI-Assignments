import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/common/product';
import { ManagementService } from 'src/app/services/management.service';

@Component({
  selector: 'app-product-grid',
  templateUrl: './product-grid.component.html',
  styleUrls: ['./product-grid.component.css']
})
export class ProductGridComponent implements OnInit {

  products : Product[]
  constructor(private service : ManagementService) { }

  ngOnInit(): void {
    this.listOfProducts()
  }

  listOfProducts() {
    this.service.getAllProducts().subscribe(data=>{console.log(data)
      this.products = data
    })
  }

}
