import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from 'src/app/common/category';
import { Product } from 'src/app/common/product';
import { ManagementService } from 'src/app/services/management.service';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {

  categories : Category[]
  product : Product = new Product(1,"","",1,"",0,"","",1)
  constructor(private service : ManagementService, private route : Router) { }

  ngOnInit(): void {
    this.listOfCategories()
  }
  listOfCategories() {
    this.service.getAllCategories().subscribe(data=>{console.log(data)
    this.categories = data})
  }

  onsubmit(){
    //console.log(this.product)
    this.service.saveProduct(this.product).subscribe(()=>{
      this.route.navigateByUrl("/products")
    })
  }

}




