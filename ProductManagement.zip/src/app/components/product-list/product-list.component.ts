import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/common/product';
import { ManagementService } from 'src/app/services/management.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products : Product[]
  constructor(private service : ManagementService) { }

  ngOnInit(): void {

    this.listOfProducts()

  }

  listOfProducts() {
    this.service.getAllProducts().subscribe(data=>{console.log(data)
      this.products = data
    })
  }

}
