import { Component, OnInit } from '@angular/core';
import { Salesperson } from '../salesperson';

@Component({
  selector: 'app-sales-person-list',
  templateUrl: './sales-person-list.component.html',
  styleUrls: ['./sales-person-list.component.css']
})
export class SalesPersonListComponent implements OnInit {

  name : string = "Himakar";

  s1 : Salesperson = new Salesperson("Arun", "Kumar", "arun@gmail.com", 25000, "300");
  salesPersonList : Salesperson [] = [this.s1,
                          new Salesperson("swathi", "S", "swathi@gmail.com", 30000, "500"),
                          new Salesperson("Rahul", "Kumar", "rahul@gmail.com", 25000, "250"),
                          new Salesperson("ajin", "Thomas", "thomas@gmail.com", 35000, "550")
                        ]

  formModel : Salesperson = new Salesperson("", "", "", 0, "");
  
  constructor() { }

  ngOnInit(): void {
    console.log(this.formModel)
  }

  onSubmit(){
    this.salesPersonList.push(this.formModel);
  }

}
