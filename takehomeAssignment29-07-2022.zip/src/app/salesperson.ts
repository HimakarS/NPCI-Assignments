export class Salesperson {

    constructor(public firstName : string,
                public lastName : string,
                public email : string,
                public salary : number,
                public salesVolume : string
            ){ }

}


